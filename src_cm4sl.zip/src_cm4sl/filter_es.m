data = readmatrix('steering_wheel.csv'); % lub readtable jeśli masz nagłówki
time = data(:,1);     % kolumna z czasem
signal = data(:,4);   % kolumna z sygnałem z czujnika skrętu
simData = timeseries(signal, time);
