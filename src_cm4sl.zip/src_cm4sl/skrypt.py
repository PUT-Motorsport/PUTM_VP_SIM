
# UWAGA
# aby powiazac matalba z pythonem trzeba w konsoli matlaba ustanowic sesje poprzez matlab.engine.shareEngine
# !! nie wyłączać symulacji z konsoli pythona !! - jeżeli tak, wymagany jest restart całego matlaba

import sys
import matlab.engine
import numpy as np
from pathlib import Path

# Nalezy uzywac pythona 3.10
sys.path.append("C:/IPG/carmaker/win64-12.0.1/Python/python3.10")

tire_file = Path(r"D:\formula-carmaker-main\FCM_Projects\FS_race\Data\Tire\Examples\CONTINENTAL_FS_205_510_R13_80kPa")           # plik opony

# znalezienie aktywanej sesji matlaba
sessions = matlab.engine.find_matlab()

# polaczenie matlaba z pythonem
eng = matlab.engine.connect_matlab(sessions[0])  # lub nazwa sesji -- 0 lub 1 w zaleznosci co dziala

# ustawienie czasu symulacji
#eng.set_param('OPENXWD', 'StopTime', '60', nargout=0) # ustawiac tylko na torach bez okrazen takie jak skidpad czy acc

# wylaczene warningow
eng.eval("warning('off', 'all')", nargout=0)


# zakresy parametrów - przemek
lb = np.array([0.8, 0.8, 2.0, 2.0, 50, -80])
ub = np.array([1.2, 1.2, 3.0, 3.0, 100, -40])

# parametry PSO
n_particles = 20
n_vars = 6
max_iters = 30

w = 0.6
c1 = 1.7
c2 = 1.7


optimization_time = 16.400302939


################################
# funkcja do nadpisywania opon #
################################

def update_tire_file(tire_file, params):
    lines = tire_file.read_text().splitlines()
    new_lines = []
    for line in lines:
        if "Scale.LMUX" in line:
            new_lines.append(f"Scale.LMUX = {params[0]}")
        elif "Scale.LMUY" in line:
            new_lines.append(f"Scale.LMUY = {params[1]}")
        elif "Long.PDX1" in line:
            new_lines.append(f"Long.PDX1 = {params[2]}")
        elif "Lat.PDY1" in line:
            new_lines.append(f"Lat.PDY1 = {params[3]}")
        elif "Long.PKX1" in line:
            new_lines.append(f"Long.PKX1 = {params[4]}")
        elif "Lat.PKY1" in line:
            new_lines.append(f"Lat.PKY1 = {params[5]}")
        else:
            new_lines.append(line)
    tire_file.write_text("\n".join(new_lines))


########################
# funkcja do symulacji #
########################

def run_simulation_and_get_error(eng, tire_file, params, target_time=optimization_time):
    # 1. update pliku opony
    update_tire_file(tire_file, params)

    # 2. odpal symulację
    print(f"   Uruchamiam symulację z parametrami: {params}")
    out = eng.sim('OPENXWD', nargout=1)

    # 3. logi z simulinka
    logsout = eng.getfield(out, 'sigsOut')
    
    # czas
    time = eng.getElement(logsout, 'time')
    time_values = eng.getfield(time, 'Values')
    time_data = eng.getfield(time_values, 'Data')

    # prędkość
    vel = eng.getElement(logsout, 'vel')
    vel_values = eng.getfield(vel, 'Values')
    vel_data = eng.getfield(vel_values, 'Data')

    # ay_real
    ay_real = eng.getElement(logsout, 'ay_real')
    ay_real_values = eng.getfield(ay_real, 'Values')
    ay_real_data = eng.getfield(ay_real_values, 'Data')

    # ay_sim
    ay_sim = eng.getElement(logsout, 'ay_sim')
    ay_sim_values = eng.getfield(ay_sim, 'Values')
    ay_sim_data = eng.getfield(ay_sim_values, 'Data')

    diff = []

    for i in zip(ay_real_data,ay_sim_data):
        diff.append(abs(i[0][0] - i[1][0]))

    err = np.mean(diff)

    sim_time = time_data[-1][0] - time_data[0][0]

    print("Średnia prędkość", np.average(vel_data))

    print(f"   Symulowany czas = {sim_time:.4f}, target = {target_time:.4f}, error = {err:.4f}")

    return err



#####################
# INICJALIZACJA PSO #
#####################

positions = np.random.uniform(lb, ub, (n_particles, n_vars))
velocities = np.zeros_like(positions)

pbest_positions = positions.copy()
pbest_errors = np.full(n_particles, np.inf)

gbest_position = None
gbest_error = np.inf



#############
# PĘTLA PSO #
#############

for iteration in range(max_iters):
    print("\n===============================")
    print(f"ITERACJA {iteration + 1} / {max_iters}")
    print("===============================")

    for i in range(n_particles):
        error = run_simulation_and_get_error(eng, tire_file, positions[i])

        if error < pbest_errors[i]:
            pbest_errors[i] = error
            pbest_positions[i] = positions[i].copy()

        if error < gbest_error:
            gbest_error = error
            gbest_position = positions[i].copy()

    # aktualizacja pozycji i prędkości
    for i in range(n_particles):
        r1 = np.random.rand(n_vars)
        r2 = np.random.rand(n_vars)

        velocities[i] = (
            w * velocities[i]
            + c1 * r1 * (pbest_positions[i] - positions[i])
            + c2 * r2 * (gbest_position - positions[i])
        )
        positions[i] += velocities[i]
        positions[i] = np.clip(positions[i], lb, ub)

    print(f"== Najlepszy błąd tej iteracji: {gbest_error:.4f} ==")




#################
# WYNIK KOŃCOWY #
#################
print("\n===================================")
print("NAJLEPSZE ZNALEZIONE PARAMETRY")
print("===================================")
param_names = ["LMUX", "LMUY", "PDX1", "PDY1", "PKX1", "PKY1"]
for name, val in zip(param_names, gbest_position):
    print(f"{name} = {val:.4f}")

print(f"\nMinimalny błąd RMS = {gbest_error:.4f}")
