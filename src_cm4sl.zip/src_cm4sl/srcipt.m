% Car Data
g=9.81;
L=1.53;
lr=0.765;
lf=L-lr;
h=0.25;
m=211 + 80;
ls=1.242;
rw=0.193;
drive_ratio=14.25;
% Motor & TV
mu=1.48;
max_moment = 13;
Ku=1/700*-1;
Mz_p=300;
Mz_I=100;

K_slip=20;
s_max=0.1;

load("AeroFD.mat")
load("AeroFL.mat")
load("AeroFS.mat")
%load("motor_maps.mat")
%load("stator_current_line_rms.mat")

